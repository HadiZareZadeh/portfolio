<template>
  <div class="min-h-screen">
    <!-- Hero Section -->
    <section class="bg-animated-gradient min-h-screen flex items-center">
      <div class="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 py-20">
        <div class="grid lg:grid-cols-2 gap-12 items-center">
          <!-- Left Column - Text Content -->
          <div class="space-y-8">
            <div v-reveal>
              <h1 class="text-5xl lg:text-6xl font-bold heading-gradient animate-fade-in-up">
                Hadi ZareZadeh
              </h1>
              <p class="text-2xl lg:text-3xl text-gray-600 mt-4">
                Software Developer · Python, Backend & Automation
              </p>
            </div>
            
            <div v-reveal class="space-y-6">
              <p class="text-lg text-gray-700 leading-relaxed">
                Computer science graduate, freelancing as a developer since 2021. I mostly write Python and PHP: e-learning platforms in Laravel and Vue, automation for Android apps, and a Telegram bot. Alongside that I study machine learning (computer vision and NLP so far) and run language models locally. I'm looking for a backend, automation or Python role, ideally with some AI work in it.
              </p>
              
              <div class="flex flex-col sm:flex-row gap-4">
                <RouterLink 
                  to="/projects" 
                  class="btn btn-primary animate-float"
                >
                  See My Projects
                </RouterLink>
                <RouterLink 
                  to="/about" 
                  class="btn btn-outline"
                >
                  About Me
                </RouterLink>
                <a
                  :href="base + 'Hadi_ZareZadeh_Resume.pdf'"
                  target="_blank"
                  rel="noopener noreferrer"
                  class="btn btn-outline"
                >
                  Resume (PDF)
                </a>
                <RouterLink 
                  to="/contact" 
                  class="btn btn-outline"
                >
                  Contact
                </RouterLink>
              </div>
            </div>
          </div>
          
          <!-- Right Column - Avatar -->
          <div v-reveal class="flex justify-center lg:justify-end">
            <div 
              ref="avatarCard"
              class="relative w-80 h-80 rounded-2xl overflow-hidden shadow-soft cursor-pointer"
              @mousemove="handleMouseMove"
              @mouseleave="resetTilt"
            >
              <img 
                :src="base + 'images/avatar.png'" 
                alt="Hadi ZareZadeh, software developer"
                class="w-full h-full object-cover"
                loading="eager"
              />
            </div>
          </div>
        </div>
      </div>
    </section>
  </div>
</template>

<script setup>
import { ref, onMounted } from 'vue'

const avatarCard = ref(null)
const isShown = ref(false)

const base = import.meta.env.BASE_URL

// uses local /images/avatar.png

const handleMouseMove = (e) => {
  if (!avatarCard.value) return
  
  const rect = avatarCard.value.getBoundingClientRect()
  const centerX = rect.left + rect.width / 2
  const centerY = rect.top + rect.height / 2
  
  const mouseX = e.clientX - centerX
  const mouseY = e.clientY - centerY
  
  const tiltX = (mouseY / rect.height) * 20
  const tiltY = (mouseX / rect.width) * -20
  
  avatarCard.value.style.transform = `perspective(800px) rotateX(${tiltX}deg) rotateY(${tiltY}deg)`
}

const resetTilt = () => {
  if (avatarCard.value) {
    avatarCard.value.style.transform = 'perspective(800px) rotateX(0deg) rotateY(0deg)'
  }
}

onMounted(() => {
  // Trigger reveal animation
  setTimeout(() => {
    isShown.value = true
  }, 100)
})
</script>
